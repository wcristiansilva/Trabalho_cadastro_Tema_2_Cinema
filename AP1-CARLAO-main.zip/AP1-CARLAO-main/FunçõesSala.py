"""
Funções do menu Sala
"""


def ListaTodasSalas():
    print("Teste")


def ListarElementoLista(BD):
    # recebendo a procura:
    Elemento = input("Digite o que deseja procurar:")
    # variavel que vai indicar se no final não achou:
    achou = False

    # Pegar cada lista de BDSALAS;
    # Ver se o Elemento é o procurado
    for Elemento in BD:
        if Elemento in BD[0]:
            print("Procura encontrada!")
            print(Elemento)
            achou = True
            input("Tecle <enter>")
    if not achou:
        print("Não encontrei o que procura", Elemento)
        input("Tecle <enter>")
    print("** Procura Finalizada **")


def IncluirSala():  # Falta Tratar da entrada de código da sala.
    # if opcao == 1:
    # pegando dados da Sala,
    # criando uma lista,
    # armazenando na lista BD
    # criando uma lista vazia:
    # BDSALAS = []
    Sala = {}
    DadosSala = []

    cont1 = True
    op = 0

    # pegando dados e inserindo na lista de Sala:
    while op < 2:

        Codigo = int(input("Digite o Código da Sala: "))

        # Testa se já tem o código no dicionário
        # print("** Código Existente no Sistema **\n")
        # Codigo = int(input("Digite o Código da Sala: "))

        Nome = input("Digite o nome da Sala: ")
        Capacidade = int(input("Digite a Capacidade da Sala: "))
        TipoExibicao = input("Digite o Tipo de Exibição da Sala: ")
        Acessibilidade = input("Informe a Acessibilidade da Sala: ")

        # Adiciona os Dados na Lista DadosSala
        DadosSala.append(Nome)
        DadosSala.append(Capacidade)
        DadosSala.append(TipoExibicao)
        DadosSala.append(Acessibilidade)

        Sala[Codigo] = DadosSala

        print("\n** Dados inseridos com sucesso!**\n")

        input("Tecle <enter>")
        op += 1

    return Sala


def AlterarOuExcluirSalas(BD):
    teste = "teste"
    teste1 = teste + BD
    return teste1


"""
Funções do menu Sessões
"""

"""
Funções do menu Relatórios
"""

# {1: ['asd', 3, 'asd', 'asd', 'sad', 3, 'asd', 'asd']}
